import json
import pytest

from app.main import create_app


@pytest.fixture
def client(tmp_path):
    app = create_app(data_file=str(tmp_path / "submissions.json"))
    app.config["TESTING"] = True
    return app.test_client(), tmp_path / "submissions.json"


VALID = {
    "name": "Ayesha Khan",
    "reg_no": "FA21-BCS-001",
    "title": "Lab 3 - Docker",
    "url": "https://github.com/ayesha/lab3",
}


def test_valid_submission_is_saved_and_listed(client):
    c, path = client
    resp = c.post("/submit", data=VALID)
    assert resp.status_code == 201
    saved = json.loads(path.read_text())
    assert len(saved) == 1 and saved[0]["reg_no"] == "FA21-BCS-001"
    page = c.get("/").get_data(as_text=True)
    assert "Lab 3 - Docker" in page and "FA21-BCS-001" in page


def test_missing_registration_number_is_rejected(client):
    c, path = client
    data = {**VALID, "reg_no": ""}
    resp = c.post("/submit", data=data)
    assert resp.status_code == 400
    assert "Registration number is required." in resp.get_data(as_text=True)
    assert not path.exists()


def test_invalid_url_is_rejected_and_not_saved(client):
    c, path = client
    data = {**VALID, "url": "not-a-url"}
    resp = c.post("/submit", data=data)
    assert resp.status_code == 400
    assert "valid URL" in resp.get_data(as_text=True)
    assert not path.exists()
