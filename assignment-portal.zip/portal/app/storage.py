import json
import os
from datetime import datetime, timezone


def load(path):
    if not os.path.exists(path):
        return []
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def add(path, record):
    items = load(path)
    record = {**record, "submitted_at": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")}
    items.append(record)
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(items, f, indent=2)
    return record
