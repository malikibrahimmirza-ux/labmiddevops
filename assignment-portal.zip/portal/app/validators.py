"""Validation rules for assignment submissions."""
from urllib.parse import urlparse

REQUIRED_FIELDS = {
    "name": "Name is required.",
    "reg_no": "Registration number is required.",
    "title": "Assignment title is required.",
    "url": "Submission URL is required.",
}


def is_valid_url(value: str) -> bool:
    try:
        parsed = urlparse(value)
    except ValueError:
        return False
    return parsed.scheme in ("http", "https") and bool(parsed.netloc) and " " not in value


def validate_submission(data: dict) -> dict:
    """Return {field: message}. Empty dict means the submission is valid."""
    errors = {}
    for field, message in REQUIRED_FIELDS.items():
        if not (data.get(field) or "").strip():
            errors[field] = message
    url = (data.get("url") or "").strip()
    if url and not is_valid_url(url):
        errors["url"] = "Enter a valid URL starting with http:// or https://."
    return errors
