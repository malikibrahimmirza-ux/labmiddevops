import os
from flask import Flask, jsonify, render_template, request

from . import storage
from .validators import validate_submission

FIELDS = ("name", "reg_no", "title", "url")


def create_app(data_file=None):
    app = Flask(__name__)
    app.config["DATA_FILE"] = data_file or os.environ.get("DATA_FILE", "data/submissions.json")

    def clean(source):
        return {f: (source.get(f) or "").strip() for f in FIELDS}

    @app.get("/")
    def index():
        return render_template("index.html", errors={}, values={}, message=None,
                               submissions=storage.load(app.config["DATA_FILE"]))

    @app.post("/submit")
    def submit():
        values = clean(request.form)
        errors = validate_submission(values)
        if errors:
            return render_template("index.html", errors=errors, values=values, message=None,
                                   submissions=storage.load(app.config["DATA_FILE"])), 400
        storage.add(app.config["DATA_FILE"], values)
        return render_template("index.html", errors={}, values={},
                               message="Submission saved.",
                               submissions=storage.load(app.config["DATA_FILE"])), 201

    @app.get("/api/submissions")
    def list_api():
        return jsonify(storage.load(app.config["DATA_FILE"]))

    @app.post("/api/submissions")
    def create_api():
        values = clean(request.get_json(silent=True) or {})
        errors = validate_submission(values)
        if errors:
            return jsonify({"errors": errors}), 400
        return jsonify(storage.add(app.config["DATA_FILE"], values)), 201

    return app


if __name__ == "__main__":
    create_app().run(debug=True, port=int(os.environ.get("PORT", 5000)))
