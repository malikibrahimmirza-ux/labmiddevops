"""Local HTTP receiver: POST /report -> saves test-report.json.

Usage: python receiver/receiver.py [--port 8000] [--out test-report.json]
Optional: set RECEIVER_TOKEN; clients must then send header X-Report-Token.
"""
import argparse
import json
import os
import tempfile
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

REQUIRED = {"repository", "branch", "commit_sha", "run_id", "timestamp",
            "tests", "total", "passed", "failed", "status"}


class Handler(BaseHTTPRequestHandler):
    out_path = "test-report.json"

    def _reply(self, code, body):
        data = json.dumps(body).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        self._reply(200, {"ok": True, "service": "test-report-receiver"})

    def do_POST(self):
        if self.path.rstrip("/") != "/report":
            return self._reply(404, {"error": "POST to /report"})
        token = os.environ.get("RECEIVER_TOKEN")
        if token and self.headers.get("X-Report-Token") != token:
            return self._reply(401, {"error": "bad token"})
        try:
            length = int(self.headers.get("Content-Length", 0))
            report = json.loads(self.rfile.read(length))
        except (ValueError, json.JSONDecodeError):
            return self._reply(400, {"error": "invalid JSON"})
        missing = REQUIRED - set(report)
        if missing:
            return self._reply(400, {"error": f"missing fields: {sorted(missing)}"})
        # atomic write so a half-written file is never visible
        fd, tmp = tempfile.mkstemp(dir=os.path.dirname(os.path.abspath(self.out_path)))
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(report, f, indent=2)
        os.replace(tmp, self.out_path)
        print(f"[receiver] saved {self.out_path}: {report['status']} "
              f"({report['passed']}/{report['total']} passed) @ {report['commit_sha'][:7]}")
        self._reply(200, {"saved": self.out_path})

    def log_message(self, *a):
        pass


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--port", type=int, default=8000)
    p.add_argument("--out", default="test-report.json")
    a = p.parse_args()
    Handler.out_path = a.out
    print(f"[receiver] listening on http://0.0.0.0:{a.port}/report -> {a.out}")
    ThreadingHTTPServer(("0.0.0.0", a.port), Handler).serve_forever()
