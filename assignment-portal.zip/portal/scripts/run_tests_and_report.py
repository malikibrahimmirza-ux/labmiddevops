"""Run pytest, build the JSON report, POST it to RECEIVER_URL, exit with pytest's code."""
import json
import os
import subprocess
import sys
import urllib.request
import xml.etree.ElementTree as ET
from datetime import datetime, timezone

JUNIT = "report.xml"


def run_pytest():
    return subprocess.run([sys.executable, "-m", "pytest", "-v", f"--junitxml={JUNIT}"]).returncode


def parse_junit():
    tests = []
    for case in ET.parse(JUNIT).getroot().iter("testcase"):
        failure = case.find("failure")
        error = case.find("error")
        bad = failure if failure is not None else error
        tests.append({
            "name": f"{case.get('classname')}::{case.get('name')}",
            "result": "failed" if bad is not None else ("skipped" if case.find("skipped") is not None else "passed"),
            "message": (bad.get("message") or "")[:1000] if bad is not None else None,
        })
    return tests


def build_report(tests):
    passed = sum(t["result"] == "passed" for t in tests)
    failed = sum(t["result"] == "failed" for t in tests)
    return {
        "repository": os.environ.get("GITHUB_REPOSITORY", "local/run"),
        "branch": os.environ.get("GITHUB_REF_NAME", "local"),
        "commit_sha": os.environ.get("GITHUB_SHA", "local"),
        "run_id": os.environ.get("GITHUB_RUN_ID", "local"),
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "tests": tests,
        "total": len(tests),
        "passed": passed,
        "failed": failed,
        "status": "passed" if failed == 0 and tests else "failed",
    }


def summary(r):
    lines = [f"Result: {r['status'].upper()}",
             f"Repository: {r['repository']}  Branch: {r['branch']}",
             f"Commit: {r['commit_sha']}  Run: {r['run_id']}",
             f"Total: {r['total']}  Passed: {r['passed']}  Failed: {r['failed']}", ""]
    for t in r["tests"]:
        lines.append(f"- {t['name']}: {t['result']}" + (f" ({t['message']})" if t["message"] else ""))
    return "\n".join(lines)


def send(report):
    url = os.environ.get("RECEIVER_URL")
    if not url:
        print("RECEIVER_URL not set; skipping delivery.")
        return
    headers = {"Content-Type": "application/json"}
    if os.environ.get("RECEIVER_TOKEN"):
        headers["X-Report-Token"] = os.environ["RECEIVER_TOKEN"]
    req = urllib.request.Request(url, json.dumps(report).encode(), headers, method="POST")
    for attempt in range(1, 4):
        try:
            with urllib.request.urlopen(req, timeout=15) as resp:
                print(f"Report delivered to receiver (HTTP {resp.status}).")
                return
        except Exception as exc:  # noqa: BLE001
            print(f"Delivery attempt {attempt} failed: {exc}")
    print("::warning::Could not deliver report to receiver. Is it and the tunnel running?")


if __name__ == "__main__":
    code = run_pytest()
    report = build_report(parse_junit())
    with open("test-report.json", "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2)
    with open("summary.txt", "w", encoding="utf-8") as f:
        f.write(summary(report))
    send(report)
    sys.exit(code)  # a failing test fails this step and the job
